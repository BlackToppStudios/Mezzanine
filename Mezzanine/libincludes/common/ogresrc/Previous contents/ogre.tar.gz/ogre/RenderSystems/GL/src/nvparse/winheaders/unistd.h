// to make flex and vc++ play nice together
